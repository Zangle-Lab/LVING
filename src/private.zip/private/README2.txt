
-- Files for the Matlab File Exchange contribution "Fast Gaussian Point Spread Function Fitting (MEX)" --

Precompiled ceres library and mex files for Windows 7 64-bit. Compiled using Visual Studio Professional 2012.
For the files to work you need the "Visual C++ Redistributable for Visual Studio 2012 Update 4" which you can download from www.microsoft.com.
Make sure all files are in the directory of the Matlab functions before calling them.
